# Caaguazú — Theme WordPress

Theme classic (no FSE) portado del sitio PHP `caaguazu-site/`. Sin dependencias de plugins.

## Instalación

1. Subir `caaguazu-theme.zip` desde **Apariencia → Temas → Añadir nuevo → Subir tema**.
2. Activarlo.
3. Ir a **Ajustes → Enlaces permanentes** y guardar (refresca las rewrite rules para el CPT `noticias`).
4. Crear las páginas con estos slugs exactos (en blanco, el theme las renderiza con su hero default):
   - `sobre-caaguazu`
   - `servicios`
   - `transparencia`
   - `ecosistema`
   - `contacto`
   *(No crear `noticias` como página: el CPT ya reserva ese slug para el archivo `/noticias/`.)*
5. En **Apariencia → Menús**, crear un menú con esas páginas + Noticias y asignarlo a "Menú principal" y "Menú móvil (drawer)". Si no se crea, el theme cae en un menú por defecto.
6. En **Ajustes → Lectura**, "Tu página de inicio muestra → Una página estática → Página de inicio: (crear una página vacía llamada Inicio)". El theme detecta `is_front_page()` y carga `front-page.php` con todas las secciones.

## Edición de contenido

- **Home** (hero, identidad, ecosistema, audiencias, transparencia, footer): **Apariencia → Personalizar → Contenido del Home**.
- **Noticias**: menú lateral **Noticias** (CPT propio, no es el de "Entradas"). Cada noticia tiene categoría (taxonomía `caaguazu_news_cat`) y un campo "Minutos de lectura" en la sidebar.
- **Logo**: Personalizar → Identidad del sitio → Logotipo.

## Mapeo del sitio original

| Original                          | Theme                                              |
|-----------------------------------|----------------------------------------------------|
| `index.php` (router `?p=slug`)    | Routing nativo de WordPress (permalinks)           |
| `includes/header.php`             | `header.php`                                       |
| `includes/footer.php`             | `footer.php`                                       |
| `includes/config.php` ($ROUTES)   | Páginas WP + Customizer                            |
| `includes/data.php` ($IDENTITY…)  | Customizer (con defaults idénticos en `inc/customizer-defaults.php`) |
| `includes/data.php` ($NEWS)       | CPT `caaguazu_news`                                |
| `pages/home.php`                  | `front-page.php`                                   |
| `pages/stub.php`                  | `page.php` (con hero defaults heredados del stub)  |
| `pages/buscar.php`                | `search.php`                                       |
| `assets/css/main.css`             | `assets/css/main.css` (sin cambios)                |
| `assets/js/main.js`               | `assets/js/main.js` (sin cambios)                  |

## Notas

- **CSS y JS no se tocaron**. Los selectores que usa el JS (`#header`, `#heroMedia`, `#heroVideo`, `.reveal`, `#burger`, `#drawer`, etc.) se preservan tal cual en las plantillas.
- **`<body data-page="...">`** se mantiene; lo setea `header.php` vía `caaguazu_current_page_slug()`. El JS lo usa para activar sticky/parallax solo en home.
- El **selector de idioma (ES/GN/EN)** sigue siendo UI-only, igual que el original. Para i18n real conectar Polylang o WPML, o crear un theme child.
- El **buscador del header** apunta a `/?s=` (buscador nativo de WP) en vez de `/?p=buscar`. La página `search.php` reusa la UI original.
- El **CPT noticias** está expuesto en REST (`show_in_rest: true`) — funciona con el editor de bloques sin problemas.

## Próximos pasos sugeridos

- Reemplazar las imágenes Unsplash y el video Pexels por assets oficiales subidos a Media Library, y setearlos como featured images o desde el Customizer.
- Si el menú móvil necesita estilos distintos al desktop, separar las locations `primary` y `mobile`.
- Para sub-portales reales bajo subdominios, montar instancias independientes (no plugins multisite obligatorios) — el footer ya soporta listar dinámicamente los del Customizer.
