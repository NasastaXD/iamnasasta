<?php
/**
 * Front page — Home de Caaguazú.
 *
 * Replica las 6 secciones del home.php original: hero, identidad,
 * ecosistema, audiencias, quiz, noticias y transparencia.
 *
 * @package Caaguazu
 */

get_header();

$identity_defaults = caaguazu_identity_defaults();
$eco_defaults      = caaguazu_ecosystem_defaults();
$aud_defaults      = caaguazu_audiences_defaults();

$hero_video  = caaguazu_opt( 'hero_video_url', 'https://videos.pexels.com/video-files/2491284/2491284-uhd_2560_1440_24fps.mp4' );
$hero_poster = caaguazu_opt_image( 'hero_poster', 'https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=1920&q=80' );
?>

<section class="hero" aria-label="<?php esc_attr_e( 'Caaguazú, Capital de la Madera', 'caaguazu' ); ?>">
	<div class="hero-media" id="heroMedia">
		<?php if ( $hero_video ) : ?>
			<video id="heroVideo" autoplay muted loop playsinline preload="metadata"
				poster="<?php echo esc_url( $hero_poster ); ?>">
				<source src="<?php echo esc_url( $hero_video ); ?>" type="video/mp4">
			</video>
		<?php else : ?>
			<img src="<?php echo esc_url( $hero_poster ); ?>" alt="">
		<?php endif; ?>
	</div>
	<div class="hero-overlay"></div>
	<div class="hero-inner hero-fade">
		<p class="eyebrow"><?php echo esc_html( caaguazu_opt( 'hero_eyebrow', 'Departamento de Paraguay' ) ); ?></p>
		<h1><?php echo esc_html( caaguazu_opt( 'hero_title', 'Caaguazú' ) ); ?></h1>
		<p class="sub"><?php echo esc_html( caaguazu_opt( 'hero_sub', 'Capital de la Madera' ) ); ?></p>
		<p class="lead"><?php echo esc_html( caaguazu_opt( 'hero_lead', 'Donde los bosques subtropicales, los oficios heredados y una comunidad bilingüe escriben el presente de un departamento que mira al futuro.' ) ); ?></p>
	</div>
	<span class="scroll-hint" aria-hidden="true"></span>
	<?php if ( $hero_video ) : ?>
		<button class="video-toggle" id="videoToggle" aria-label="<?php esc_attr_e( 'Pausar video', 'caaguazu' ); ?>">❚❚</button>
	<?php endif; ?>
</section>

<section class="container identity">
	<?php for ( $i = 0; $i < 3; $i++ ) :
		$d       = $identity_defaults[ $i ];
		$eyebrow = caaguazu_opt( "identity_{$i}_eyebrow", $d['eyebrow'] );
		$title   = caaguazu_opt( "identity_{$i}_title",   $d['title'] );
		$body    = caaguazu_opt( "identity_{$i}_body",    $d['body'] );
		$img     = caaguazu_opt_image( "identity_{$i}_image", $d['image'] );
		$reverse = ( $i % 2 === 1 ) ? 'reverse' : '';
	?>
		<article class="move reveal <?php echo esc_attr( $reverse ); ?>">
			<div class="move-img"><img src="<?php echo esc_url( $img ); ?>" alt="" loading="lazy"></div>
			<div>
				<p class="eyebrow"><?php echo esc_html( $eyebrow ); ?></p>
				<h2><?php echo esc_html( $title ); ?></h2>
				<p><?php echo esc_html( $body ); ?></p>
				<a class="arrow" href="<?php echo esc_url( caaguazu_page_url( 'sobre-caaguazu' ) ); ?>"><?php esc_html_e( 'Conocer más', 'caaguazu' ); ?></a>
			</div>
		</article>
	<?php endfor; ?>
</section>

<section class="eco">
	<div class="container">
		<div class="section-head reveal">
			<p class="eyebrow"><?php esc_html_e( 'Ecosistema', 'caaguazu' ); ?></p>
			<h2><?php echo esc_html( caaguazu_opt( 'eco_section_title', 'Un portal, múltiples puertas' ) ); ?></h2>
			<p><?php echo esc_html( caaguazu_opt( 'eco_section_body', 'Caaguazu.net es el hub central de una red de sub-portales especializados. Cada uno mantiene su voz, todos comparten la misma identidad.' ) ); ?></p>
		</div>
		<div class="eco-grid">
			<?php for ( $i = 0; $i < 3; $i++ ) :
				$d     = $eco_defaults[ $i ];
				$tag   = caaguazu_opt( "eco_{$i}_tag",   $d['tag'] );
				$title = caaguazu_opt( "eco_{$i}_title", $d['title'] );
				$body  = caaguazu_opt( "eco_{$i}_body",  $d['body'] );
				$cta   = caaguazu_opt( "eco_{$i}_cta",   $d['cta'] );
				$url   = caaguazu_opt( "eco_{$i}_url",   $d['url'] );
				$img   = caaguazu_opt_image( "eco_{$i}_image", $d['image'] );
				$soon  = empty( $url );
				$tag_el = $soon ? 'div' : 'a';
				$attrs  = $soon ? '' : sprintf( 'href="%s" target="_blank" rel="noreferrer"', esc_url( $url ) );
			?>
				<<?php echo $tag_el; ?> class="eco-card reveal <?php echo $soon ? 'soon' : ''; ?>" <?php echo $attrs; ?>>
					<div class="img"><img src="<?php echo esc_url( $img ); ?>" alt="" loading="lazy"></div>
					<div class="body">
						<span class="eco-tag"><?php echo esc_html( $tag ); ?></span>
						<h3><?php echo esc_html( $title ); ?></h3>
						<p class="desc"><?php echo esc_html( $body ); ?></p>
						<span class="arrow"><?php echo esc_html( $cta ); ?></span>
					</div>
				</<?php echo $tag_el; ?>>
			<?php endfor; ?>
		</div>
	</div>
</section>

<section class="container">
	<div class="section-head reveal">
		<p class="eyebrow"><?php esc_html_e( 'Servicios', 'caaguazu' ); ?></p>
		<h2><?php esc_html_e( 'Servicios para todos', 'caaguazu' ); ?></h2>
	</div>
	<div class="aud-grid">
		<?php for ( $i = 0; $i < 3; $i++ ) :
			$d     = $aud_defaults[ $i ];
			$icon  = caaguazu_opt( "aud_{$i}_icon",  $d['icon'] );
			$title = caaguazu_opt( "aud_{$i}_title", $d['title'] );
			$body  = caaguazu_opt( "aud_{$i}_body",  $d['body'] );
			$cta   = caaguazu_opt( "aud_{$i}_cta",   $d['cta'] );
			$slug  = caaguazu_opt( "aud_{$i}_slug",  $d['slug'] );
		?>
			<a class="aud reveal" href="<?php echo esc_url( caaguazu_page_url( $slug ) ); ?>">
				<div class="ico"><?php echo wp_kses_post( $icon ); ?></div>
				<h3><?php echo esc_html( $title ); ?></h3>
				<p class="desc"><?php echo esc_html( $body ); ?></p>
				<span class="arrow"><?php echo esc_html( $cta ); ?></span>
			</a>
		<?php endfor; ?>
	</div>
</section>

<section class="quiz-wrap">
	<div class="container">
		<div class="quiz reveal">
			<p class="eyebrow"><?php esc_html_e( 'Ayudanos a orientarte', 'caaguazu' ); ?></p>
			<h2><?php esc_html_e( '¿Qué te trajo a Caaguazú hoy?', 'caaguazu' ); ?></h2>
			<p class="intro"><?php esc_html_e( 'Respondé una pregunta corta y te recomendamos por dónde empezar.', 'caaguazu' ); ?></p>
			<div class="quiz-opts">
				<?php foreach ( array(
					array( '🏡', __( 'Soy residente', 'caaguazu' ) ),
					array( '🌿', __( 'Voy de visita', 'caaguazu' ) ),
					array( '📈', __( 'Busco invertir', 'caaguazu' ) ),
					array( '📚', __( 'Soy estudiante', 'caaguazu' ) ),
					array( '✨', __( 'Otro', 'caaguazu' ) ),
				) as $opt ) : ?>
					<button class="quiz-opt" type="button">
						<span class="e"><?php echo esc_html( $opt[0] ); ?></span>
						<span><?php echo esc_html( $opt[1] ); ?></span>
					</button>
				<?php endforeach; ?>
			</div>
			<p class="note"><?php esc_html_e( 'Próximamente — quiz interactivo completo.', 'caaguazu' ); ?></p>
		</div>
	</div>
</section>

<section class="container">
	<div class="news-head reveal">
		<div class="section-head">
			<p class="eyebrow"><?php esc_html_e( 'Noticias y publicaciones', 'caaguazu' ); ?></p>
			<h2><?php esc_html_e( 'Lo último de Caaguazú', 'caaguazu' ); ?></h2>
		</div>
		<a class="arrow" href="<?php echo esc_url( get_post_type_archive_link( 'caaguazu_news' ) ); ?>"><?php esc_html_e( 'Ver todas', 'caaguazu' ); ?></a>
	</div>
	<div class="news-grid">
		<?php
		$news = new WP_Query( array(
			'post_type'      => 'caaguazu_news',
			'posts_per_page' => 3,
			'no_found_rows'  => true,
		) );

		if ( $news->have_posts() ) :
			while ( $news->have_posts() ) : $news->the_post();
				$cat   = caaguazu_news_primary_term( get_the_ID() );
				$mins  = (int) get_post_meta( get_the_ID(), '_caaguazu_read_minutes', true );
				$thumb = get_the_post_thumbnail_url( get_the_ID(), 'caaguazu-card' );
		?>
				<article class="news reveal">
					<div class="img">
						<?php if ( $thumb ) : ?>
							<img src="<?php echo esc_url( $thumb ); ?>" alt="" loading="lazy">
						<?php endif; ?>
					</div>
					<div class="body">
						<?php if ( $cat ) : ?><span class="cat"><?php echo esc_html( $cat ); ?></span><?php endif; ?>
						<h3><?php the_title(); ?></h3>
						<p class="meta">
							<?php echo esc_html( get_the_date() ); ?>
							<?php if ( $mins ) : ?> · <?php printf( esc_html__( '%d min de lectura', 'caaguazu' ), $mins ); ?><?php endif; ?>
						</p>
						<p class="ex"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 25 ) ); ?></p>
						<a class="arrow" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Leer más', 'caaguazu' ); ?></a>
					</div>
				</article>
		<?php
			endwhile;
			wp_reset_postdata();
		else :
			// Sin noticias todavía — placeholder que coincide con el layout original.
			$placeholder_news = array(
				array( 'Desarrollo', 'Caaguazú lanza programa de reforestación con escuelas rurales',
					'La iniciativa involucra a más de 40 instituciones educativas en la plantación de especies nativas.',
					'12 de mayo, 2026', '4 min',
					'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&w=1200&q=80' ),
				array( 'Cultura', 'Festival de la Madera celebra su 15ª edición en Coronel Oviedo',
					'Tres días de exposiciones, talleres de carpintería tradicional y gastronomía local.',
					'8 de mayo, 2026', '3 min',
					'https://images.unsplash.com/photo-1452860606245-08befc0ff44b?auto=format&fit=crop&w=1200&q=80' ),
				array( 'Gobierno', 'Nuevas plataformas digitales simplifican trámites departamentales',
					'Más de 30 gestiones ya pueden realizarse en línea desde el portal de servicios.',
					'2 de mayo, 2026', '5 min',
					'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1200&q=80' ),
			);
			foreach ( $placeholder_news as $n ) :
		?>
				<article class="news reveal">
					<div class="img"><img src="<?php echo esc_url( $n[5] ); ?>" alt="" loading="lazy"></div>
					<div class="body">
						<span class="cat"><?php echo esc_html( $n[0] ); ?></span>
						<h3><?php echo esc_html( $n[1] ); ?></h3>
						<p class="meta"><?php echo esc_html( $n[3] ); ?> · <?php echo esc_html( $n[4] ); ?> de lectura</p>
						<p class="ex"><?php echo esc_html( $n[2] ); ?></p>
						<a class="arrow" href="<?php echo esc_url( get_post_type_archive_link( 'caaguazu_news' ) ); ?>"><?php esc_html_e( 'Leer más', 'caaguazu' ); ?></a>
					</div>
				</article>
		<?php
			endforeach;
		endif;
		?>
	</div>
</section>

<section class="transp">
	<div class="transp-bg" aria-hidden="true"></div>
	<div class="transp-grad" aria-hidden="true"></div>
	<div class="container">
		<div class="reveal">
			<p class="eyebrow"><?php esc_html_e( 'Transparencia', 'caaguazu' ); ?></p>
			<h2><?php echo esc_html( caaguazu_opt( 'transp_title', 'Gobierno abierto, datos accesibles' ) ); ?></h2>
			<p><?php echo esc_html( caaguazu_opt( 'transp_body', 'Publicamos presupuesto, licitaciones y datos abiertos en formatos reutilizables. La transparencia es el cimiento del ecosistema.' ) ); ?></p>
		</div>
		<div class="transp-cta reveal">
			<a class="btn btn-white" href="<?php echo esc_url( caaguazu_page_url( 'transparencia' ) ); ?>"><?php echo esc_html( caaguazu_opt( 'transp_cta1', 'Ver presupuesto' ) ); ?></a>
			<a class="btn btn-ghost" href="<?php echo esc_url( caaguazu_page_url( 'transparencia' ) ); ?>"><?php echo esc_html( caaguazu_opt( 'transp_cta2', 'Datos abiertos' ) ); ?></a>
		</div>
	</div>
</section>

<?php
get_footer();
