<?php
/**
 * Header del theme.
 *
 * @package Caaguazu
 */

$current_slug = caaguazu_current_page_slug();
$is_home      = caaguazu_is_home();
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#006400">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?> data-page="<?php echo esc_attr( $current_slug ); ?>">
<?php wp_body_open(); ?>

<header class="header <?php echo $is_home ? '' : 'solid'; ?>" id="header">
	<div class="header-inner">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="logo" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?> — <?php esc_attr_e( 'inicio', 'caaguazu' ); ?>">
			<?php if ( has_custom_logo() ) : ?>
				<?php the_custom_logo(); ?>
			<?php else : ?>
				<span class="logo-name"><?php bloginfo( 'name' ); ?></span>
				<span class="logo-tld">.net</span>
			<?php endif; ?>
		</a>

		<nav class="nav" aria-label="<?php esc_attr_e( 'Principal', 'caaguazu' ); ?>">
			<?php caaguazu_render_nav( 'primary', $current_slug ); ?>
		</nav>

		<div class="header-actions">
			<a href="<?php echo esc_url( get_search_link() ? get_search_link() : home_url( '/?s=' ) ); ?>" class="icon-btn" aria-label="<?php esc_attr_e( 'Buscar', 'caaguazu' ); ?>">🔍</a>
			<div class="lang" role="group" aria-label="<?php esc_attr_e( 'Idioma', 'caaguazu' ); ?>">
				<button class="on" data-lang="ES">ES</button>
				<button data-lang="GN">GN</button>
				<button data-lang="EN">EN</button>
			</div>
			<button class="icon-btn burger" id="burger" aria-label="<?php esc_attr_e( 'Abrir menú', 'caaguazu' ); ?>">☰</button>
		</div>
	</div>
</header>

<div class="drawer-bg" id="drawerBg"></div>
<aside class="drawer" id="drawer" aria-hidden="true">
	<button class="close" id="drawerClose" aria-label="<?php esc_attr_e( 'Cerrar', 'caaguazu' ); ?>">×</button>
	<?php caaguazu_render_nav( 'mobile', $current_slug ); ?>
	<a href="<?php echo esc_url( home_url( '/?s=' ) ); ?>"><?php esc_html_e( 'Buscar', 'caaguazu' ); ?></a>
</aside>

<main id="main">
