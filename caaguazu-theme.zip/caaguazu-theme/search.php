<?php
/**
 * Resultados de búsqueda. Reusa la UI del pages/buscar.php original.
 *
 * @package Caaguazu
 */

get_header(); ?>

<nav class="container breadcrumb" aria-label="<?php esc_attr_e( 'Migas de pan', 'caaguazu' ); ?>">
	<ol>
		<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Inicio', 'caaguazu' ); ?></a></li>
		<li>›</li>
		<li aria-current="page"><?php esc_html_e( 'Buscar', 'caaguazu' ); ?></li>
	</ol>
</nav>

<div class="container search-wrap">
	<p class="eyebrow" style="text-align:center"><?php esc_html_e( 'Buscar', 'caaguazu' ); ?></p>
	<h1 style="text-align:center;font-size:clamp(40px,6vw,64px);margin-top:16px"><?php esc_html_e( '¿Qué estás buscando?', 'caaguazu' ); ?></h1>

	<form class="search-form" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
		<span style="margin-left:8px;color:var(--text-muted)">🔍</span>
		<input type="search" name="s" value="<?php echo esc_attr( get_search_query() ); ?>"
			placeholder="<?php esc_attr_e( 'Buscar páginas, noticias, trámites…', 'caaguazu' ); ?>"
			aria-label="<?php esc_attr_e( 'Búsqueda', 'caaguazu' ); ?>">
		<button type="submit"><?php esc_html_e( 'Buscar', 'caaguazu' ); ?></button>
	</form>

	<div class="filters">
		<?php foreach ( array( 'Todos', 'Páginas', 'Noticias', 'Trámites', 'Sub-portales' ) as $i => $f ) : ?>
			<button type="button" class="chip <?php echo $i === 0 ? 'on' : ''; ?>"><?php echo esc_html( $f ); ?></button>
		<?php endforeach; ?>
	</div>

	<div class="scopes">
		<strong style="text-transform:uppercase;letter-spacing:.1em"><?php esc_html_e( 'Ámbito:', 'caaguazu' ); ?></strong>
		<?php foreach ( array( 'caaguazu.net', 'turismo', 'cead' ) as $s ) : ?>
			<label><input type="checkbox" checked disabled> <?php echo esc_html( $s ); ?></label>
		<?php endforeach; ?>
	</div>

	<?php if ( get_search_query() ) : ?>
		<?php if ( have_posts() ) : ?>
			<div class="news-grid" style="margin-top:48px">
				<?php while ( have_posts() ) : the_post(); ?>
					<article class="news">
						<?php if ( has_post_thumbnail() ) : ?>
							<div class="img"><?php the_post_thumbnail( 'caaguazu-card', array( 'loading' => 'lazy' ) ); ?></div>
						<?php endif; ?>
						<div class="body">
							<span class="cat"><?php echo esc_html( get_post_type_object( get_post_type() )->labels->singular_name ); ?></span>
							<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
							<p class="ex"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 25 ) ); ?></p>
							<a class="arrow" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Ver', 'caaguazu' ); ?></a>
						</div>
					</article>
				<?php endwhile; ?>
			</div>
			<?php the_posts_pagination(); ?>
		<?php else : ?>
			<div class="search-empty"><?php printf( esc_html__( 'No hay resultados para "%s".', 'caaguazu' ), esc_html( get_search_query() ) ); ?></div>
		<?php endif; ?>
	<?php else : ?>
		<div class="search-empty"><?php esc_html_e( 'Escribí algo para empezar — los resultados indexarán el hub y los sub-portales.', 'caaguazu' ); ?></div>
	<?php endif; ?>
</div>

<?php get_footer();
